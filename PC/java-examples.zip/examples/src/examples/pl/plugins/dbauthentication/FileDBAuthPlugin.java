package examples.pl.plugins.dbauthentication;

import aQute.bnd.annotation.component.Activate;
import aQute.bnd.annotation.component.Component;
import aQute.bnd.annotation.component.ConfigurationPolicy;
import gw.pl.util.FileUtil;
import gw.plugin.PluginParameter;
import gw.plugin.Plugins;
import gw.plugin.credentials.CredentialsPlugin;
import gw.plugin.credentials.UsernamePasswordPairBase;
import gw.plugin.dbauth.DBAuthenticationPlugin;
import gw.plugin.dbauth.UsernamePasswordPair;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.util.Map;

/**
 * Simple class that returns a username/password pair with a null username and a db password retrieved
 * from a file specified by the "filename" property.
 */
@Component(configurationPolicy = ConfigurationPolicy.require)
@PluginParameter(name="passwordfile", type= PluginParameter.Type.File)
@PluginParameter(name="usernamefile", type= PluginParameter.Type.File)
@PluginParameter(name="CredentialPlugin.Key", type=PluginParameter.Type.String, helpText = "This is a key to get the user/password from the CredentialPlugin")
public class FileDBAuthPlugin implements DBAuthenticationPlugin {

  private static final String PASSWORD_FILE_PROPERTY = "passwordfile";
  private static final String USERNAME_FILE_PROPERTY = "usernamefile";
  private static final String CREDENTIAL_KEY = "CredentialPlugin.Key";

  private String _passwordfile;
  private String _usernamefile;
  private String _credentialKey;

  @SuppressWarnings("unused")
  @Activate
  void start(Map<?, ?> properties) {
    _passwordfile = (String) properties.get(PASSWORD_FILE_PROPERTY);
    _usernamefile = (String) properties.get(USERNAME_FILE_PROPERTY);
    _credentialKey = (String) properties.get(CREDENTIAL_KEY);
  }

  @Override
  public UsernamePasswordPair retrieveUsernameAndPassword(String dbName) {
    if (_credentialKey != null) {
      CredentialsPlugin plugin = Plugins.isEnabled(CredentialsPlugin.class) ? Plugins.get(CredentialsPlugin.class) : null;
      if (plugin != null) {
        UsernamePasswordPairBase cred = plugin.retrieveUsernameAndPassword(_credentialKey);
        if (cred != null) {
          return new UsernamePasswordPair(cred.getUsername(), cred.getPassword());
        }
      }
    }
    try {
      String password = null;
      if (_passwordfile != null) {
        password = readLine(new File(_passwordfile));
      }
      String username = null;
      if (_usernamefile != null) {
        username = readLine(new File(_usernamefile));
      }
      return new UsernamePasswordPair(username, password);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private static String readLine(File file) throws IOException {
    BufferedReader reader = new BufferedReader(FileUtil.getFileReader(file));
    String line = reader.readLine();
    reader.close();
    return line;
  }
}
