/**
 * Override this file in a given customer implementation, to have systems initialized in app.abstractReload
 * @param isFullPageReload
 */
gw.customerSpecificInit = function (isFullPageReload) {

};