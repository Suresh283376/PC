Instructions for installing and running the Guidewire Solr External Search
(GSES) extension.

Starting with this release, GWES no longer requires or supports deployment to
an application server.  Instead, it uses a production grade embedded Jetty
container.

These instructions assume that you install GSES in the directory <GWSOLR_HOME>,
where <GWSOLR_HOME> = C:\opt\gwsolr on Windows or /opt/gwsolr on Linux, OS/X,
or AIX systems.

If you install GSES anywhere else, you must modify these instructions
accordingly.

1) Download and install the JDK.
    (http://www.oracle.com/technetwork/java/javase/downloads/index.html)

2) Copy the gwsolr archive file, pc-gwsolr.zip to directory
<GWSOLR_HOME>/pc

3) Unzip the archive into this directory (<GWSOLR_HOME>/pc)

4) Change directory to <GWSOLR_HOME>/pc/bin

5) Start Solr using the control script and the start command.  Solr will be
accessible via the default port of 8983.

    $ solr start

   Optional: You can start Solr on a different port with the -p option, e.g.

    $ solr start -p 8984

    Optional: For easier log viewing in development, you can start Solr
    in the foreground with the -f option, e.g.

    $ solr start -f -p 8985

6) Examine the log file <GWSOLR_HOME>/pc/server/logs/solr.log to
   confirm GSES started successfully

7) Enter the following url in your browser to verify that you can access the
   Solr Admin application

    http://<hostname>:8983/solr

   Note: if you launched solr on a different port, use that port here instead.

   This will take you to the main Administration page for Solr.  There are
   several administrative pages for the server as well as a core selector that
   will allow you to drill into the details of each configured core.

   Each Solr document defined will be listed as a core.  You can browse the
   existing documents, if any, on the query page as well as submit custom
   queries.

8) To stop solr, enter the following command

    $ solr stop -p 8983

Solr launch properties can be customized by editing either "solr.in.cmd"
(Windows) or "solr.in.sh" (Linux, OS/X, AIX).

If you copy these files into the config/solr folder under
$GUIDEWIRE_APPLICATION/modules/configuration, you can edit them in Studio and
your changes will be packaged the next time you run the 'gwb packageSolr'
command.
